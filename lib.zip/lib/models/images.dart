final List<String> universityImages = [
  "assets/uw1.jpg",
  "assets/uw2.jpg",
  "assets/uw3.jpg",
  "assets/uw4.jpeg",
];

final List<String>  programImages= [
  'assets/uoftLogo.jpg',
  'assets/uoft2.jpg'
];

